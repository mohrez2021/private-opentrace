package io.bluetrace.opentrace.fragment

import android.app.DatePickerDialog
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import com.google.android.gms.tasks.Task
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.HttpsCallableResult
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.UploadTask
import com.google.gson.Gson
import io.bluetrace.opentrace.*
import io.bluetrace.opentrace.logging.CentralLog
import io.bluetrace.opentrace.status.persistence.StatusRecord
import io.bluetrace.opentrace.status.persistence.StatusRecordStorage
import io.bluetrace.opentrace.streetpass.persistence.StreetPassRecord
import io.bluetrace.opentrace.streetpass.persistence.StreetPassRecordStorage
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.functions.BiFunction
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_login.*
import kotlinx.android.synthetic.main.fragment_submit_illness.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class SubmitIllnessFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_submit_illness, container, false)
    }
    var timeOfTest : Long =0
    private var disposeObj: Disposable? = null
    private var TAG = "SubmitIllnessFragment"


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        buttonSumbitCovid.setOnClickListener {
            submitLoadingProgressBarFrame.visibility = View.VISIBLE


            tv_error.text=""
            tv_error.visibility=View.GONE
            submitCovid(requireContext())

        }


        showDatePicker()


    }

    private fun submitCovid(context: Context): Task<HttpsCallableResult> {
        val functions : FirebaseFunctions = FirebaseFunctions.getInstance(BuildConfig.FIREBASE_REGION)
        val code = submitCode.text.toString()
        return functions.getHttpsCallable("submitCovid").call("{\"code\": $code , \"date\" : $timeOfTest}").addOnSuccessListener {
            val result: HashMap<String, Any> = it.data as HashMap<String, Any>
            val status = result["status"]
            if (status != null) {
                if(status == "SUCCESS") {
                    uploadData(code)
                }
            }



        }.addOnFailureListener {
            CentralLog.d("a", "[hello] Error getting hello")
            tv_error.visibility=View.VISIBLE
            tv_error.text = it.message
            submitLoadingProgressBarFrame.visibility = View.GONE

        }
    }

    private  fun uploadData(code:String){

        var observableStreetRecords = Observable.create<List<StreetPassRecord>> {
            val result = StreetPassRecordStorage(TracerApp.AppContext).getAllRecords()
            it.onNext(result)
        }
        var observableStatusRecords = Observable.create<List<StatusRecord>> {
            val result = StatusRecordStorage(TracerApp.AppContext).getAllRecords()
            it.onNext(result)
        }

        disposeObj = Observable.zip(observableStreetRecords, observableStatusRecords,

            BiFunction<List<StreetPassRecord>, List<StatusRecord>, ExportData> { records, status ->
                ExportData(
                    records,
                    status
                )
            }

        )
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeOn(Schedulers.io())
            .subscribe { exportedData ->
                Log.d(TAG, "records: ${exportedData.recordList}")
                Log.d(TAG, "status: ${exportedData.statusList}")

                getUploadToken(code).addOnSuccessListener {
                    val response = it.data as HashMap<String, String>
                    try {
                        val uploadToken = response["token"]
                        CentralLog.d(TAG, "uploadToken: $uploadToken")
                        var task = writeToInternalStorageAndUpload(
                            TracerApp.AppContext,
                            exportedData.recordList,
                            exportedData.statusList,
                            uploadToken,
                            code
                        )
                        task.addOnFailureListener {
                            CentralLog.d(TAG, "failed to upload")
                            tv_error.visibility=View.VISIBLE
                            tv_error.text = it.message
                            submitLoadingProgressBarFrame.visibility = View.GONE
                        }.addOnSuccessListener {
                            CentralLog.d(TAG, "submitted successfully")
                            Toast.makeText(context,"submitted successfully" , Toast.LENGTH_LONG).show()
                            submitLoadingProgressBarFrame.visibility = View.GONE
                        }
                    } catch (e: Throwable) {
                        CentralLog.d(TAG, "Failed to upload data: ${e.message}")
                        tv_error.visibility=View.VISIBLE
                        tv_error.text = e.message
                        submitLoadingProgressBarFrame.visibility = View.GONE
                    }
                }.addOnFailureListener {
                    CentralLog.d(TAG, "Invalid code")
                    tv_error.visibility=View.VISIBLE
                    tv_error.text = it.message
                    submitLoadingProgressBarFrame.visibility = View.GONE
                }
            }
    }

    private fun getUploadToken(uploadCode: String): Task<HttpsCallableResult> {
        val functions = FirebaseFunctions.getInstance(BuildConfig.FIREBASE_REGION)
        return functions
            .getHttpsCallable("getUploadToken")
            .call(uploadCode)
    }


    private fun writeToInternalStorageAndUpload(
        context: Context,
        deviceDataList: List<StreetPassRecord>,
        statusList: List<StatusRecord>,
        uploadToken: String?,
        code: String?
    ): UploadTask {
        var date = Utils.getDateFromUnix(System.currentTimeMillis())
        var gson = Gson()

        val manufacturer = Build.MANUFACTURER
        val model = Build.MODEL

        var updatedDeviceList = deviceDataList.map {
            it.timestamp = it.timestamp / 1000
            return@map it
        }

        var updatedStatusList = statusList.map {
            it.timestamp = it.timestamp / 1000
            return@map it
        }

        var map: MutableMap<String, Any> = HashMap()
        map["token"] = uploadToken as Any
        map["code"] = code as Any
        map["records"] = updatedDeviceList as Any
        map["events"] = updatedStatusList as Any

        val mapString = gson.toJson(map)

        val fileName = "StreetPassRecord_${manufacturer}_${model}_$date.json"
        val fileOutputStream: FileOutputStream

        val uploadDir = File(context.filesDir, "upload")

        if (uploadDir.exists()) {
            uploadDir.deleteRecursively()
        }

        uploadDir.mkdirs()
        val fileToUpload = File(uploadDir, fileName)
//        fileOutputStream = context.openFileOutput(fileName, Context.MODE_PRIVATE)
        fileOutputStream = FileOutputStream(fileToUpload)

        fileOutputStream.write(mapString.toByteArray())
        fileOutputStream.close()

        CentralLog.i(TAG, "File wrote: ${fileToUpload.absolutePath}")

        return uploadToCloudStorage(context, fileToUpload)
    }

    private fun uploadToCloudStorage(context: Context, fileToUpload: File): UploadTask {
        CentralLog.d(TAG, "Uploading to Cloud Storage")

        val bucketName = BuildConfig.FIREBASE_UPLOAD_BUCKET
        val storage = FirebaseStorage.getInstance("gs://${bucketName}")
        var storageRef = storage.getReferenceFromUrl("gs://${bucketName}")

        val dateString = SimpleDateFormat("yyyyMMdd").format(Date())
        var streetPassRecordsRef =
            storageRef.child("streetPassRecords/$dateString/${fileToUpload.name}")

        val fileUri: Uri =
            FileProvider.getUriForFile(
                context,
                "${BuildConfig.APPLICATION_ID}.fileprovider",
                fileToUpload
            )

        var uploadTask = streetPassRecordsRef.putFile(fileUri)
        uploadTask.addOnCompleteListener {
            try {
                fileToUpload.delete()
                CentralLog.i(TAG, "upload file deleted")
            } catch (e: Exception) {
                CentralLog.e(TAG, "Failed to delete upload file")
            }
        }
        return uploadTask
    }

    private fun showDatePicker() {
        // DatePicker

        billDate_editText_billUpload.setText(SimpleDateFormat("dd/MM/yyyy").format(System.currentTimeMillis()))
        timeOfTest = System.currentTimeMillis()

        val cal = Calendar.getInstance()

        val dateSetListener = DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
            cal.set(Calendar.YEAR, year)
            cal.set(Calendar.MONTH, monthOfYear)
            cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)

            val myFormat = "dd/MM/yyyy" // mention the format you need
            val sdf = SimpleDateFormat(myFormat, Locale.US)
            timeOfTest = cal.timeInMillis
            billDate_editText_billUpload.setText(sdf.format(cal.time))
        }

        billDate_editText_billUpload.setOnClickListener {

            val dialog = DatePickerDialog(requireContext(), dateSetListener,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH))
            dialog.datePicker.maxDate = CalendarHelper.getCurrentDateInMills()
            dialog.show()
        }

    }
    override fun onDestroy() {
        super.onDestroy()
        disposeObj?.dispose()
    }


}
