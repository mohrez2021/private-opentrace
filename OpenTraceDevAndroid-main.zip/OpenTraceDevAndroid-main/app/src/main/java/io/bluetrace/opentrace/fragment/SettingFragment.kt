package io.bluetrace.opentrace.fragment

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Context.ALARM_SERVICE
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import io.bluetrace.opentrace.R
import io.bluetrace.opentrace.TracerApp
import io.bluetrace.opentrace.receivers.AlarmReceiver
import kotlinx.android.synthetic.main.fragment_setting.*


class SettingFragment : Fragment(), /** Other Classes, */
    AdapterView.OnItemSelectedListener {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_setting, container, false)
    }
    var timer = arrayOf("Select One","10 Minutes","1 Hour", "3 Hour", "6 Hour", "12 Hour", "1 Day", "3 Day", "1 Week")
    lateinit var shared : SharedPreferences

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        shared = requireActivity().getSharedPreferences("setting" , Context.MODE_PRIVATE)


        buttonSettingSave.setOnClickListener {
            if(checkBox.isChecked && spinner.selectedItemPosition==0){
                Toast.makeText(requireContext(),"select repeat time",Toast.LENGTH_LONG).show()
            }else {
                settingLoadingProgressBarFrame.visibility = View.VISIBLE
                val edit = shared.edit()
                edit.putBoolean("AutoCalcRisk", checkBox.isChecked)
                edit.putInt(
                    "AutoCalcRiskTime",
                    if (!checkBox.isChecked) 0 else spinner.selectedItemPosition
                )
                edit.apply()
                schedulePushNotifications(checkBox.isChecked)
                settingLoadingProgressBarFrame.visibility = View.GONE
                Toast.makeText(requireContext(),"Saved!",Toast.LENGTH_LONG).show()
            }

        }
        layoutAutoCalc.visibility = View.GONE
        if(shared.getBoolean("AutoCalcRisk", false)){
            checkBox.isChecked =true
            layoutAutoCalc.visibility = View.VISIBLE
            spinner!!.setOnItemSelectedListener(this)
            val array_adapter =
                ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, timer)
            array_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner!!.setAdapter(array_adapter)
            spinner.setSelection(shared.getInt("AutoCalcRiskTime", 0))
        }
        checkBox.setOnClickListener {
            if(layoutAutoCalc.isVisible){
                layoutAutoCalc.visibility = View.GONE
                spinner.setSelection(0)
            }else {
                layoutAutoCalc.visibility = View.VISIBLE
                spinner!!.setOnItemSelectedListener(this)
                val array_adapter =
                    ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, timer)
                array_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spinner!!.setAdapter(array_adapter)
            }
        }

    }

    override fun onItemSelected(arg0: AdapterView<*>, arg1: View, position: Int, id: Long) {

    }

    override fun onNothingSelected(arg0: AdapterView<*>) {

    }

    private val alarmManager = TracerApp.AppContext.getSystemService(ALARM_SERVICE) as AlarmManager
    private val alarmPendingIntent by lazy {
        val intent = Intent(TracerApp.AppContext, AlarmReceiver::class.java)
        PendingIntent.getBroadcast(TracerApp.AppContext, 0, intent, 0)
    }

    fun schedulePushNotifications(Auto :Boolean) {
        if (!Auto) {
            alarmManager.cancel(alarmPendingIntent)
            return
        }

        var repeatTime:Long =60000
        if(spinner.selectedItemPosition == 1){
            repeatTime=600000
        }else if(spinner.selectedItemPosition == 2){
            repeatTime=3600000
        }else if(spinner.selectedItemPosition == 3){
            repeatTime=10800000
        }else if(spinner.selectedItemPosition == 4){
            repeatTime=21600000
        }else if(spinner.selectedItemPosition == 5){
            repeatTime=43200000
        }else if(spinner.selectedItemPosition == 6){
            repeatTime=86400000
        }else if(spinner.selectedItemPosition == 7){
            repeatTime=259200000
        }else if(spinner.selectedItemPosition == 8){
            repeatTime=604800000
        }

        alarmManager.setRepeating(
            AlarmManager.RTC_WAKEUP,
            System.currentTimeMillis(),
            repeatTime,
            alarmPendingIntent
        )
    }




}
