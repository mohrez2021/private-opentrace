package io.bluetrace.opentrace.fragment

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.github.aachartmodel.aainfographics.aachartcreator.*
import com.google.firebase.functions.FirebaseFunctions
import com.google.gson.GsonBuilder
import io.bluetrace.opentrace.BuildConfig
import io.bluetrace.opentrace.R
import io.bluetrace.opentrace.TracerApp
import io.bluetrace.opentrace.logging.CentralLog
import io.bluetrace.opentrace.recycler.RiskAdapter
import io.bluetrace.opentrace.recycler.RiskItemsViewModel
import io.bluetrace.opentrace.status.persistence.StatusRecord
import io.bluetrace.opentrace.status.persistence.StatusRecordStorage
import io.bluetrace.opentrace.streetpass.persistence.StreetPassRecord
import io.bluetrace.opentrace.streetpass.persistence.StreetPassRecordStorage
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.functions.BiFunction
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_risk.*
import org.json.JSONObject
import java.text.DecimalFormat
import java.util.*
import kotlin.collections.ArrayList


class RiskFragment : Fragment() {
    private var disposeObj: Disposable? = null
    private var data: ArrayList<RiskItemsViewModel>? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_risk, container, false)
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerview.layoutManager = LinearLayoutManager(requireContext())

        data = ArrayList<RiskItemsViewModel>()

        buttonRisk.setOnClickListener {
            riskLoadingProgressBarFrame.visibility = View.VISIBLE
            ShowRisk.text =""
            data?.clear()
            val adapter = data?.let { it1 -> RiskAdapter(it1) }

            recyclerview.adapter = adapter
            aa_chart_view.visibility =View.GONE
            getRisk()

        }





    }

    @RequiresApi(Build.VERSION_CODES.N)
    fun getRisk() {
        val functions : FirebaseFunctions = FirebaseFunctions.getInstance(BuildConfig.FIREBASE_REGION)
        val df = DecimalFormat("#.##")
        functions.getHttpsCallable("getRisk").call().addOnSuccessListener {
            riskLoadingProgressBarFrame.visibility = View.GONE

            if(it.data !=null){
                val result: HashMap<String, List<Any>> = it.data as HashMap<String, List<Any>>
                val result1 = result["result"];
                val covids:ArrayList<String> = ArrayList()
                val barList:ArrayList<Any> = ArrayList()
                var max :Float= 0f
                var riskCount :Float= 0f
                var count :Int= 0
                var avg :Float= 0f

                result1?.forEach { item ->
                    val a = JSONObject(item.toString())
                    if(!covids.contains(a.getString("CovidUid")))
                        covids.add(a.getString("CovidUid"))
                    data?.add(RiskItemsViewModel(
                        a.get("rssiRisk").toString(),
                        a.get("dayRisk").toString(),
                        a.get("timeRisk").toString(),
                        a.get("exposureEffect").toString(),
                        df.format(((a.get("recordRisk").toString().toFloat() * 100) / 512)).toString() + " %"
                    ))
                    if(max <= ((a.get("recordRisk").toString().toFloat() * 100) / 512)) {
                        max = ((a.get("recordRisk").toString().toFloat() * 100) / 512)
                    }
                    riskCount = riskCount + ((a.get("recordRisk").toString().toFloat() * 100) / 512)
                    count = count + 1
                    barList.add(((a.get("recordRisk").toString().toFloat() * 100) / 512))
                }
                if (result1 != null) {
                    if(result1.isNotEmpty()) {
                        avg = riskCount / count
                        riskCount = df.format(riskCount).toFloat()
                        avg = df.format(avg).toFloat()
                        max = df.format(max).toFloat()
                        if (riskCount > 100f) {
                            riskCount = 100f
                        }
                        ShowRisk.text = "Sum of Contact Score : $riskCount %" +
                                "\nAverage of Contact Score : $avg %" +
                                "\nMax Of Contact Score : $max %" +
                                "\nNumber Of Contacts : $count " +
                                "\nNumber Of Distinct Contacts : ${covids.size}"

                        val adapter = data?.let { it1 -> RiskAdapter(it1) }

                        recyclerview.adapter = adapter
                        aa_chart_view.visibility = View.VISIBLE

                        makeChart(barList.toArray())
                    }else{
                        ShowRisk.text = "no data to calc"
                    }
                }else{
                    ShowRisk.text = "no data to calc"
                }
            }else{
                ShowRisk.text = "no data to calc"
            }



        }.addOnFailureListener {
            CentralLog.d("a", "[hello] Error getting hello")
            riskLoadingProgressBarFrame.visibility = View.GONE

        }

    }
    fun makeChart(list :Array<Any>){
        val aaChartModel : AAChartModel = AAChartModel()
            .chartType(AAChartType.Line)
            .animationType(AAChartAnimationType.Bounce)
            .title("Contact Score")
            .dataLabelsEnabled(false)
            .markerSymbolStyle(AAChartSymbolStyleType.BorderBlank)
            .markerRadius(7f)
            .series(arrayOf(
                AASeriesElement()
                    .name("Score")
                    .data(list)
                    .step("center")

            ))
        aa_chart_view.aa_drawChartWithChartModel(aaChartModel)


    }


}
