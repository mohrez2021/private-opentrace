package io.bluetrace.opentrace.receivers

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.firebase.functions.FirebaseFunctions
import com.google.gson.GsonBuilder
import io.bluetrace.opentrace.*
import io.bluetrace.opentrace.fragment.ExportData
import io.bluetrace.opentrace.logging.CentralLog
import io.bluetrace.opentrace.recycler.RiskItemsViewModel
import io.bluetrace.opentrace.services.BluetoothMonitoringService
import io.bluetrace.opentrace.status.persistence.StatusRecord
import io.bluetrace.opentrace.status.persistence.StatusRecordStorage
import io.bluetrace.opentrace.streetpass.persistence.StreetPassRecord
import io.bluetrace.opentrace.streetpass.persistence.StreetPassRecordStorage
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.functions.BiFunction
import io.reactivex.schedulers.Schedulers
import org.json.JSONObject
import java.text.DecimalFormat
import java.util.HashMap


class AlarmReceiver : BroadcastReceiver() {
    private var disposeObj: Disposable? = null
    private var data: ArrayList<RiskItemsViewModel>? = null
    lateinit var mNotificationManager: NotificationManager
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onReceive(context: Context, intent: Intent) {
        mNotificationManager = TracerApp.AppContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            // Create the channel for the notification
            val mChannel =
                NotificationChannel("12345", TracerApp.AppContext.getText(R.string.get_risk_ok_title), NotificationManager.IMPORTANCE_LOW)
            mChannel.enableLights(false)
            mChannel.enableVibration(true)
            mChannel.vibrationPattern = longArrayOf(0L)
            mChannel.setSound(null, null)
            mChannel.setShowBadge(false)

            // Set the Notification Channel for the Notification Manager.
            mNotificationManager!!.createNotificationChannel(mChannel)
        }
        getRisk()
    }


    @RequiresApi(Build.VERSION_CODES.N)
    fun getRisk() {

        val observableStreetRecords = Observable.create<List<StreetPassRecord>> {
            val result = StreetPassRecordStorage(TracerApp.AppContext).getAllRecords()
            it.onNext(result)
        }
        val observableStatusRecords = Observable.create<List<StatusRecord>> {
            val result = StatusRecordStorage(TracerApp.AppContext).getAllRecords()
            it.onNext(result)
        }

        disposeObj = Observable.zip(observableStreetRecords, observableStatusRecords,

            BiFunction<List<StreetPassRecord>, List<StatusRecord>, ExportData> { records, status ->
                ExportData(
                    records,
                    status
                )
            }

        )
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeOn(Schedulers.io())
            .subscribe { exportedData ->
                Log.d("TAG", "records: ${exportedData.recordList}")
                Log.d("TAG", "status: ${exportedData.statusList}")

                val functions: FirebaseFunctions =
                    FirebaseFunctions.getInstance(BuildConfig.FIREBASE_REGION)
                val gson = GsonBuilder().create()
                val myCustomArray = gson.toJsonTree(exportedData.recordList).asJsonArray
                val df = DecimalFormat("#.##")
                functions.getHttpsCallable("getRisk").call(myCustomArray.toString())
                    .addOnSuccessListener {
                        val result: HashMap<String, List<Any>> =
                            it.data as HashMap<String, List<Any>>
                        val result1 = result["result"];
                        val covids: ArrayList<String> = ArrayList()
                        val barList: ArrayList<Any> = ArrayList()
                        var max: Float = 0f
                        var riskCount: Float = 0f
                        var count: Int = 0
                        var avg: Float = 0f

                        result1?.forEach { item ->
                            val a = JSONObject(item.toString())
                            if (!covids.contains(a.getString("CovidUid")))
                                covids.add(a.getString("CovidUid"))
                            data?.add(
                                RiskItemsViewModel(
                                    a.get("rssiRisk").toString(),
                                    a.get("dayRisk").toString(),
                                    a.get("timeRisk").toString(),
                                    a.get("exposureEffect").toString(),
                                    df.format(
                                        ((a.get("recordRisk").toString().toFloat() * 100) / 512)
                                    ).toString() + " %"
                                )
                            )
                            if (max <= ((a.get("recordRisk").toString().toFloat() * 100) / 512)) {
                                max = ((a.get("recordRisk").toString().toFloat() * 100) / 512)
                            }
                            riskCount =
                                riskCount + ((a.get("recordRisk").toString().toFloat() * 100) / 512)
                            count = count + 1
                            barList.add(((a.get("recordRisk").toString().toFloat() * 100) / 512))
                        }
                        avg = riskCount / count
                        riskCount = df.format(riskCount).toFloat()
                        avg = df.format(avg).toFloat()
                        max = df.format(max).toFloat()
                        if (riskCount > 100f) {
                            riskCount = 100f
                        }
//                        ShowRisk.text = "Sum of Contact Score : $riskCount %" +
//                                "\nAverage of Contact Score : $avg %" +
//                                "\nMax Of Contact Score : $max %" +
//                                "\nNumber Of Contacts : $count " +
//                                "\nNumber Of Distinct Contacts : ${covids.size}"



                        val des = "Sum of Contact Score : $riskCount %" +
                                "\nAverage of Contact Score : $avg %" +
                                "\nMax Of Contact Score : $max %" +
                                "\nNumber Of Contacts : $count " +
                                "\nNumber Of Distinct Contacts : ${covids.size}"

                        var intent = Intent(TracerApp.AppContext, MainActivity::class.java)
                        intent.putExtra("notif",true)
                        val activityPendingIntent = PendingIntent.getActivity(
                            TracerApp.AppContext, 0,
                            intent, PendingIntent.FLAG_UPDATE_CURRENT
                        )

                        val builder = NotificationCompat.Builder(TracerApp.AppContext, "12345")
                            .setContentTitle(TracerApp.AppContext.getText(R.string.get_risk_ok_title))
                            .setContentText(des)
                            .setOngoing(false)
                            .setPriority(Notification.PRIORITY_HIGH)
                            .setSmallIcon(R.drawable.ic_notification_warning)
                            .setContentIntent(activityPendingIntent)
                            .setTicker(des)
                            .setStyle(NotificationCompat.BigTextStyle().bigText(des))
                            .setWhen(System.currentTimeMillis())
                            .setSound(null)
                            .setVibrate(null)
                            .setColor(ContextCompat.getColor(TracerApp.AppContext, R.color.notification_tint))

                        mNotificationManager.notify(12345,builder.build())


                    }.addOnFailureListener {
                        CentralLog.d("a", "Error")

                        var intent = Intent(TracerApp.AppContext, MainActivity::class.java)
                        intent.putExtra("notif",true)
                        val activityPendingIntent = PendingIntent.getActivity(
                            TracerApp.AppContext, 0,
                            intent, PendingIntent.FLAG_UPDATE_CURRENT
                        )
                        val builder = NotificationCompat.Builder(TracerApp.AppContext, "12345")
                            .setContentTitle(TracerApp.AppContext.getText(R.string.get_risk_ok_title))
                            .setContentText("Please Calculate Your Score")
                            .setOngoing(false)
                            .setPriority(Notification.PRIORITY_HIGH)
                            .setSmallIcon(R.drawable.ic_notification_warning)
                            .setContentIntent(activityPendingIntent)
                            .setTicker("Please Calculate Your Score")
                            .setStyle(NotificationCompat.BigTextStyle().bigText("Please Calculate Your Score"))
                            .setWhen(System.currentTimeMillis())
                            .setSound(null)
                            .setVibrate(null)
                            .setColor(ContextCompat.getColor(TracerApp.AppContext, R.color.notification_tint))

                        mNotificationManager.notify(12345,builder.build())

                    }
            }


    }
}

