package io.bluetrace.opentrace.fragment

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import com.github.aachartmodel.aainfographics.aachartcreator.*
import com.google.android.gms.tasks.Task
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.HttpsCallableResult
import com.google.gson.GsonBuilder
import io.bluetrace.opentrace.*
import io.bluetrace.opentrace.logging.CentralLog
import io.bluetrace.opentrace.recycler.RiskAdapter
import io.bluetrace.opentrace.recycler.RiskItemsViewModel
import io.bluetrace.opentrace.status.persistence.StatusRecord
import io.bluetrace.opentrace.status.persistence.StatusRecordStorage
import io.bluetrace.opentrace.streetpass.persistence.StreetPassRecord
import io.bluetrace.opentrace.streetpass.persistence.StreetPassRecordStorage
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.functions.BiFunction
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_database.*
import org.json.JSONObject
import java.text.DecimalFormat
import java.util.*


class DataBaseFragment : Fragment() {
    private var disposeObj: Disposable? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_database, container, false)
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        buttonGetData.setOnClickListener {
            DatabaseLoadingProgressBarFrame.visibility = View.VISIBLE
            textViewDatabase.text =""
            val functions : FirebaseFunctions = FirebaseFunctions.getInstance(BuildConfig.FIREBASE_REGION)
            getDataBase(functions)

        }





    }

    fun getDataBase(
        functions: FirebaseFunctions
    ): Task<HttpsCallableResult> {
        return functions
            .getHttpsCallable("getDataBase")
            .call()
            .addOnSuccessListener {
                DatabaseLoadingProgressBarFrame.visibility = View.GONE
                val result: HashMap<String, Any> = it.data as HashMap<String, Any>
                textViewDatabase.text ="total Submit Uploded: " + result["totalSubmit"] + "\n" +
                        "total Records Uploded: " + result["totalSubmit"] + "\n"
                CentralLog.d("TAG", "Result from handshake pin: " + result.toString())
            }.addOnFailureListener { e ->
                DatabaseLoadingProgressBarFrame.visibility = View.GONE
                CentralLog.w("TAG", "get handshake pin (failure): ${e.message}")
            }
    }





}
