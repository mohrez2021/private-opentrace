package io.bluetrace.opentrace.recycler

data class RiskItemsViewModel(val RSSI: String,
                              val Day: String,
                              val Time: String,
                              val Exposure: String,
                              val Record: String) {
}