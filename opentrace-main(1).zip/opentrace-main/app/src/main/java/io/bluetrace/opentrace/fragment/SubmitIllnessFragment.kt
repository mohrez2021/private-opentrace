package io.bluetrace.opentrace.fragment

import android.app.DatePickerDialog
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.android.gms.tasks.Task
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.HttpsCallableResult
import io.bluetrace.opentrace.BuildConfig
import io.bluetrace.opentrace.CalendarHelper
import io.bluetrace.opentrace.R
import io.bluetrace.opentrace.logging.CentralLog
import kotlinx.android.synthetic.main.fragment_login.*
import kotlinx.android.synthetic.main.fragment_submit_illness.*
import kotlinx.android.synthetic.main.fragment_upload_page.*
import java.text.SimpleDateFormat
import java.util.*

class SubmitIllnessFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_submit_illness, container, false)
    }
    var timeOfTest : Long =0
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        buttonSumbitCovid.setOnClickListener {
            submitLoadingProgressBarFrame.visibility = View.VISIBLE


            tv_error.text=""
            tv_error.visibility=View.GONE
            submitCovid(requireContext())

        }


        showDatePicker()


    }

    private fun submitCovid(context: Context): Task<HttpsCallableResult> {
        val functions : FirebaseFunctions = FirebaseFunctions.getInstance(BuildConfig.FIREBASE_REGION)
        val code = submitCode.text.toString()
        return functions.getHttpsCallable("submitCovid").call("{\"code\": $code , \"date\" : $timeOfTest}").addOnSuccessListener {
            val result: HashMap<String, Any> = it.data as HashMap<String, Any>
            val status = result["status"]
            val result2 = result["result"]
            Toast.makeText(context,status.toString() , Toast.LENGTH_LONG).show()
            Toast.makeText(context,result2.toString() , Toast.LENGTH_LONG).show()
            submitLoadingProgressBarFrame.visibility = View.GONE



        }.addOnFailureListener {
            CentralLog.d("a", "[hello] Error getting hello")
            tv_error.visibility=View.VISIBLE
            tv_error.text = it.message
            submitLoadingProgressBarFrame.visibility = View.GONE

        }
    }

    private fun showDatePicker() {
        // DatePicker

        billDate_editText_billUpload.setText(SimpleDateFormat("dd/MM/yyyy").format(System.currentTimeMillis()))
        timeOfTest = System.currentTimeMillis()

        val cal = Calendar.getInstance()

        val dateSetListener = DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
            cal.set(Calendar.YEAR, year)
            cal.set(Calendar.MONTH, monthOfYear)
            cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)

            val myFormat = "dd/MM/yyyy" // mention the format you need
            val sdf = SimpleDateFormat(myFormat, Locale.US)
            timeOfTest = cal.timeInMillis
            billDate_editText_billUpload.setText(sdf.format(cal.time))
        }

        billDate_editText_billUpload.setOnClickListener {

            val dialog = DatePickerDialog(requireContext(), dateSetListener,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH))
            dialog.datePicker.maxDate = CalendarHelper.getCurrentDateInMills()
            dialog.show()
        }

    }


}
