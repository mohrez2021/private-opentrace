package io.bluetrace.opentrace.streetpass

class BlacklistEntry(val uniqueIdentifier: String, val timeEntered: Long)
