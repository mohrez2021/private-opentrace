package io.bluetrace.opentrace.streetpass

import io.bluetrace.opentrace.BuildConfig

const val ACTION_DEVICE_SCANNED = "${BuildConfig.APPLICATION_ID}.ACTION_DEVICE_SCANNED"
