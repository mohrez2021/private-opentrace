
interface Contacts {
    uid : string,
    uid2 : any,
    rssi: number,
    contactTime: number,
    startTime: number,
    endTime: number,
}

export default Contacts;
