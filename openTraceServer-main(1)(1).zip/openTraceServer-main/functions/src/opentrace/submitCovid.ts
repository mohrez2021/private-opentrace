import config from "../config";
import * as admin from "firebase-admin";
import formatTimestamp from "./utils/formatTimestamp";
import * as functions from "firebase-functions";

const submitCovid = async (uid: string, data: any, context: functions.https.CallableContext) => {
  const dataJson = JSON.parse(data)
  console.log(dataJson)
  
  const valid =await getDBCollection(dataJson.code)
  console.error('valid', valid);

  if(valid){
      try {
        return {
          status: 'SUCCESS',
          result: await storeSubmitCovid(uid,{
            Uid: uid,
            code: dataJson.code,
            Time: dataJson.date / 1000
          })
        }
      } catch (error) {
        console.error('submitCovid: Error while trying make a submitCovid record.', error);
        throw new functions.https.HttpsError('internal', 'Internal Server Error.');
      }
    }else {
      throw new functions.https.HttpsError('internal', 'Code not vaild');
    }

};

export async function storeSubmitCovid(uid: string, log: object) {
    const id : string = uid.substr(0,5) +"_"+  Date.now() / 1000
    const writeResult = await admin.firestore().collection(config.upload.submitCovid).doc(id).set(log);
    console.log('storeSubmitCovid:', 'SubmitCovid log is recorded successfully at', formatTimestamp(writeResult.writeTime.seconds));
    return writeResult
}

async function getDBCollection(inCode:number)  {
  const server =  admin.firestore().collection(config.upload.submitCodes).get();
return server.then((querySnapshot) => {
     let activeCode : Boolean = false
    querySnapshot.forEach((doc) => {
      console.error('doc.data().code', doc.data().code);
      console.error('inCode', inCode);

       if(doc.data().code == inCode){
         if(doc.data().expireTime > (Date.now() / 1000)){
          activeCode = true
          return
         }
       }
    });
    console.error('activeCode', activeCode);

   
  return activeCode;
  
 });
}

 
export default submitCovid;