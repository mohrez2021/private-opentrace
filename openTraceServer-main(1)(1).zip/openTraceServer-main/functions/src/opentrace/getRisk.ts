import config from "../config";
import * as admin from "firebase-admin";
import { getAllEncryptionKeys } from "./utils/getEncryptionKey";
import StreetPassRecord from "./types/StreetPassRecord";
import formatTimestamp from "./utils/formatTimestamp";
import { decryptTempID } from "./getTempIDs";
import Contacts from "./types/Contacts";
import * as functions from "firebase-functions";


const getRisk = async (uid: string, data: any[], context: functions.https.CallableContext) => {

  const records = await GetContact(data)
  const covids = await getDBCollection();
  const covidsUid: any[] = []

  covids.forEach((item) => {
    if (((Date.now() / 1000) - 1209600) < item.Time && item.Time < (Date.now() / 1000)) {
      covidsUid.push(item.Uid)
    }
  });

  const contacts: Contacts[] = []

  const Risks: any[] = []
  records.forEach((item) => {
    if (!covidsUid.includes(item.contactId)) {
      return;
    }

    if (contacts.length == 0) {
      const tempContact: Contacts = {
        uid: "",
        uid2: "",
        rssi: 0,
        contactTime: 0,
        startTime: 0,
        endTime: 0
      }
      tempContact.uid = uid
      tempContact.uid2 = item.contactId
      tempContact.rssi = item.rssi
      tempContact.startTime = item.timestamp
      tempContact.endTime = 60
      tempContact.contactTime = 60
      contacts.push(tempContact)
      return
    }
    if ( !merage(contacts,item) ) {
          const tempContact: Contacts = {
            uid: "",
            uid2: "",
            rssi: 0,
            contactTime: 0,
            startTime: 0,
            endTime: 0
          }
          tempContact.uid = uid
          tempContact.uid2 = item.contactId
          tempContact.rssi = item.rssi
          tempContact.startTime = item.timestamp
          tempContact.endTime = item.timestamp + 10
          tempContact.contactTime = 10
          contacts.push(tempContact)
    }
  });

  var totalRisk = 0
  contacts.forEach((item) => {
    if (item.contactTime > 10) {
      var dRisk = (dayRisk(item.startTime))
      var rRisk = (rssiRisk(item.rssi))
      var eEffect = exposureEffect(signalCat(item.rssi), ((item.contactTime) / 60))
      var tRisk = timeRisk(eEffect)

      var recordRisk = (tRisk * dRisk * rRisk)

      totalRisk = totalRisk + recordRisk


      Risks.push({
        "uid": item.uid,
        "CovidUid": item.uid2,
        "timeRisk": tRisk.toFixed(2),
        "dayRisk": dRisk.toFixed(2),
        "rssiRisk": rRisk.toFixed(2),
        "exposureEffect": eEffect.toFixed(2),
        "recordRisk": recordRisk.toFixed(2),
        "totalRisk": totalRisk.toFixed(2)
      })

    }
  });

  return {
    status: "SUCCESS",
    result: Risks
  }
};

function merage(contacts:Contacts[] , uid : StreetPassRecord): Boolean{
  for (var _i = contacts.length -1; _i >= 0; _i--) { 
  if (uid.contactId == contacts[_i].uid2) {
    if (signalCat(uid.rssi) == signalCat(contacts[_i].rssi)) {
      if ((uid.timestamp - contacts[_i].startTime) < 1800) {
        contacts[_i].endTime = uid.timestamp
        contacts[_i].contactTime = uid.timestamp - contacts[_i].startTime
        contacts[_i].rssi = uid.rssi
        return true
      }
    }
    break
  }
}
return false
}

async function getDBCollection(): Promise<any[]> {
  const server = admin.firestore().collection(config.upload.submitCovid).get();
  return server.then((querySnapshot) => {
    const tempDoc: any[] = [];
    const ids: any[] = [];
    querySnapshot.forEach((doc) => {
      tempDoc.push(doc.data());
    });

    tempDoc.forEach((i) => {
      ids.push({ Time: i.Time, Uid: i.Uid, Des: i.Des });
    });
    return ids;

  });

}

function signalCat(inputSignal: number): string {
  var signal = inputSignal
  if (inputSignal < 0) {
    signal = inputSignal * -1
  }
  const immediate: number = 40
  const near: number = 53
  const medium: number = 60
  if (signal <= immediate) {
    return "immediate"
  } else if (signal <= near) {
    return "near"
  } else if (signal <= medium) {
    return "medium"
  } else {
    return "other"

  }
}

function exposureEffect(signal: string, time: number): number {
  if (signal == "immediate") {
    return (time * 1.5)
  } else if (signal == "near") {
    return (time * 1)
  } else if (signal == "medium") {
    return (time * 0.5)
  } else {
    return (time * 0)

  }
}

function dayRisk(inputDay: number): number {
  var dayTimestamp = (Date.now() / 1000) - (inputDay)
  var day = dayTimestamp / 86400
  console.log("a", Date.now(), "  b", inputDay, "  c", dayTimestamp, " n", day)
  if (day >= 14) {
    return 1
  } else if (day >= 12) {
    return 2
  } else if (day >= 10) {
    return 2
  } else if (day >= 8) {
    return 4
  } else if (day >= 6) {
    return 6
  } else if (day >= 4) {
    return 8
  } else if (day >= 2) {
    return 8
  } else {
    return 8
  }
}

function timeRisk(time: number): number {

  if (time > 30) {
    return 8
  } else if (time > 25 && time <= 30) {
    return 8
  } else if (time > 20 && time <= 25) {
    return 8
  } else if (time > 15 && time <= 20) {
    return 7
  } else if (time > 10 && time <= 15) {
    return 7
  } else if (time > 5 && time <= 10) {
    return 4
  } else if (time > 0 && time <= 5) {
    return 1
  } else {
    return 0
  }
}

function rssiRisk(inputRssi: number): number {
  var rssi = inputRssi
  if (inputRssi < 0) {
    rssi = inputRssi * -1
  }
  if (rssi > 73) {
    return 0
  } else if (rssi > 63 && rssi <= 73) {
    return 0
  } else if (rssi > 51 && rssi <= 63) {
    return 1
  } else if (rssi > 33 && rssi <= 51) {
    return 8
  } else if (rssi > 23 && rssi <= 33) {
    return 8
  } else if (rssi > 15 && rssi <= 23) {
    return 8
  } else if (rssi > 10 && rssi <= 15) {
    return 8
  } else {
    return 8
  }
}
async function GetContact(data2: any) {
  const { records } = JSON.parse('{ "records" :' + data2 + ' }');
  const record = await validateRecords(records)
  const record2 = record.sort(function (a, b) {
    return a["timestamp"] - b["timestamp"];
  });

  return record2

}



/**
 * Validate records and convert temp ID to UID
 */
async function validateRecords(records: StreetPassRecord[]): Promise<StreetPassRecord[]> {
  if (!records) {
    return [];
  }
  const encryptionKeys = await getAllEncryptionKeys();

  records.forEach(record => {
    record.timestamp = record.timestamp > 10000000000 ? record.timestamp / 1000 : record.timestamp; // Convert Epoch ms to Epoch s
    record.timestampString = formatTimestamp(record.timestamp);
    validateRecord(record, encryptionKeys);
  });

  return records;
}

/**
 * Validate records by decrypting and checking if broadcast message's timestamp is within validity period.
 * Multiple encryption keys can be provided, they are tried until 1 succeeds.
 * @param record
 * @param encryptionKeys: all possible encryption keys
 */
function validateRecord(record: StreetPassRecord, encryptionKeys: Buffer[]) {
  record.isValid = false;

  if (!record.msg) {
    record.invalidReason = "no_msg";
    return;
  }

  for (const encryptionKey of encryptionKeys) {
    try {
      //Decrypt UUID
      const { uid, startTime, expiryTime } = decryptTempID(record.msg, encryptionKey);
      record.contactId = uid;
      record.contactIdValidFrom = startTime;
      record.contactIdValidTo = expiryTime;

      if (record.timestamp < startTime || record.timestamp > expiryTime) {
        console.warn('validateRecord:', 'ID timestamp is not valid.', 'ID startTime:', formatTimestamp(startTime), 'ID expiryTime:', formatTimestamp(expiryTime), 'timestamp:', formatTimestamp(record.timestamp));
        record.isValid = false;
        record.invalidReason = "expired_id";
      } else {
        record.isValid = true;
      }

      break;
    } catch (error) {
      console.warn('validateRecord:', 'Error while decrypting temp ID.', error.message);
    }
  }

  if (!record.isValid && !record.invalidReason) {
    //Decryption using all encryption keys have failed. Setting the full temp ID as contactId for downstream processing.
    record.contactId = record.msg;
    record.invalidReason = "failed_decryption";
  }

}

export default getRisk;