import FunctionConfig from "./opentrace/types/FunctionConfig";
import Authenticator from "./opentrace/utils/Authenticator";
import PinGenerator from "./opentrace/utils/PinGenerator";
import DataForwarder from "./opentrace/utils/DataForwarder";

const config: FunctionConfig = {
  projectId: "445313676009",
  regions: ["us-central1" , "us-east1" , "us-east4" , "europe-west1" , "europe-west2" , "asia-east2" , "asia-northeast1"],
  utcOffset: 0,
  authenticator: new Authenticator(),
  encryption: {
    defaultAlgorithm: "aes-256-gcm",
    keyPath: "EncryptionKey",
    defaultVersion: 1,
  },
  tempID: {
    validityPeriod: 0.25, // in hours
    refreshInterval: 12,  // in hours
    batchSize: 100, // sufficient for 24h+
  },
  upload: {
    pinGenerator: new PinGenerator(),
    bucket: "uploadbucket-dev", //
    recordsDir: "records",
    testsDir: "tests",
    tokenValidityPeriod: 2, // in hours
    bucketForArchive: "archivebucket-dev",
    logDBCollection: "uploadLogs",
    recordsDBCollection: "recordsLogs",
    dataForwarder: new DataForwarder(),
    submitCovid: "submitCovids",
    submitCodes :"submitCodes"
  },
};


export default config;
