import * as admin from "firebase-admin";
import config from "../config";

const IsValidSubmitCode = async  (inCode:number) => {
const server =  admin.firestore().collection(config.upload.submitCodes).get();
  return server.then((querySnapshot) => {
       let activeCode : Boolean = false
      querySnapshot.forEach((doc) => {
        console.error('doc.data().code', doc.data().code);
        console.error('inCode', inCode);
  
         if(doc.data().code == inCode){
           if(doc.data().expireTime > (Date.now() / 1000)){
            activeCode = true
            return
           }
         }
      });
      console.error('activeCode', activeCode);
  
     
    return activeCode;
    
   });
  };

  export default IsValidSubmitCode;
