import config from "../config";
import * as admin from "firebase-admin";
import StreetPassRecord from "./types/StreetPassRecord";
import Contacts from "./types/Contacts";
import * as functions from "firebase-functions";
import { validateToken } from "./getUploadToken";


const getRisk = async (inputUid: string, context: functions.https.CallableContext) => {

  const records = await getRecords()
  const covids = await getDBCollection();
  const covidsUid: any[] = []

  covids.forEach((item) => {
    if (((Date.now() / 1000) - 1209600) < item.Time && item.Time < (Date.now() / 1000)) {
      covidsUid.push(item.Uid)
    }
  });

  const contacts: Contacts[] = []

  const Risks: any[] = []
  for await (const item2 of records) {
    if(item2.records == undefined){
      return;
    }

    if(item2.records.length == 0){
      return;
    }
    const record = SortRecords(item2.records)
    const token = item2.token
    let { uid } = await validateToken(token, false);

    if(uid != inputUid){
      return;
    }
    (await record).forEach((item: StreetPassRecord) => {
      if (!covidsUid.includes(item.contactId)) {
        return;
      }

      if (contacts.length == 0) {
        const tempContact: Contacts = {
          uid: "",
          uid2: "",
          rssi: 0,
          contactTime: 0,
          startTime: 0,
          endTime: 0
        }
        tempContact.uid = inputUid
        tempContact.uid2 = item.contactId
        tempContact.rssi = item.rssi
        tempContact.startTime = item.timestamp
        tempContact.endTime = 60
        tempContact.contactTime = 60
        contacts.push(tempContact)
        return
      }
      if ( !merage(contacts,item) ) {
            const tempContact: Contacts = {
              uid: "",
              uid2: "",
              rssi: 0,
              contactTime: 0,
              startTime: 0,
              endTime: 0
            }
            tempContact.uid = inputUid
            tempContact.uid2 = item.contactId
            tempContact.rssi = item.rssi
            tempContact.startTime = item.timestamp
            tempContact.endTime = item.timestamp + 10
            tempContact.contactTime = 10
            contacts.push(tempContact)
      }
    });
};

  var totalRisk = 0
  contacts.forEach((item) => {
    if (item.contactTime > 10) {
      var dRisk = (dayRisk(item.startTime))
      var rRisk = (rssiRisk(item.rssi))
      var eEffect = exposureEffect(signalCat(item.rssi), ((item.contactTime) / 60))
      var tRisk = timeRisk(eEffect)

      var recordRisk = (tRisk * dRisk * rRisk)

      totalRisk = totalRisk + recordRisk


      Risks.push({
        "uid": item.uid,
        "CovidUid": item.uid2,
        "timeRisk": tRisk.toFixed(2),
        "dayRisk": dRisk.toFixed(2),
        "rssiRisk": rRisk.toFixed(2),
        "exposureEffect": eEffect.toFixed(2),
        "recordRisk": recordRisk.toFixed(2),
        "totalRisk": totalRisk.toFixed(2)
      })

    }
  });

  return {
    status: "SUCCESS",
    result: Risks
  }
};

function merage(contacts:Contacts[] , uid : StreetPassRecord): Boolean{
  for (var _i = contacts.length -1; _i >= 0; _i--) { 
  if (uid.contactId == contacts[_i].uid2) {
    if (signalCat(uid.rssi) == signalCat(contacts[_i].rssi)) {
      if ((uid.timestamp - contacts[_i].startTime) < 1800) {
        contacts[_i].endTime = uid.timestamp
        contacts[_i].contactTime = uid.timestamp - contacts[_i].startTime
        contacts[_i].rssi = uid.rssi
        return true
      }
    }
    break
  }
}
return false
}

async function getDBCollection(): Promise<any[]> {
  const server = admin.firestore().collection(config.upload.submitCovid).get();
  return server.then((querySnapshot) => {
    const tempDoc: any[] = [];
    const ids: any[] = [];
    querySnapshot.forEach((doc) => {
      tempDoc.push(doc.data());
    });

    tempDoc.forEach((i) => {
      ids.push({ Time: i.Time, Uid: i.Uid, Des: i.Des });
    });
    return ids;

  });

}

async function getRecords(): Promise<any[]> {
  const server = admin.firestore().collection(config.upload.recordsDBCollection).get();
  return server.then(async (querySnapshot) => {
    const recordsLogs: any[] = [];
    querySnapshot.forEach((doc) => {
      recordsLogs.push(doc.data());
    });
    return recordsLogs;

  });

}
async function SortRecords(records: StreetPassRecord[])  {
  const record2 = records.sort(function (a, b) {
    return a["timestamp"] - b["timestamp"];
  });

  return record2

}

function signalCat(inputSignal: number): string {
  var signal = inputSignal
  if (inputSignal < 0) {
    signal = inputSignal * -1
  }
  const immediate: number = 40
  const near: number = 53
  const medium: number = 60
  if (signal <= immediate) {
    return "immediate"
  } else if (signal <= near) {
    return "near"
  } else if (signal <= medium) {
    return "medium"
  } else {
    return "other"

  }
}

function exposureEffect(signal: string, time: number): number {
  if (signal == "immediate") {
    return (time * 1.5)
  } else if (signal == "near") {
    return (time * 1)
  } else if (signal == "medium") {
    return (time * 0.5)
  } else {
    return (time * 0)

  }
}

function dayRisk(inputDay: number): number {
  var dayTimestamp = (Date.now() / 1000) - (inputDay)
  var day = dayTimestamp / 86400
  if (day >= 14) {
    return 1
  } else if (day >= 12) {
    return 2
  } else if (day >= 10) {
    return 2
  } else if (day >= 8) {
    return 4
  } else if (day >= 6) {
    return 6
  } else if (day >= 4) {
    return 8
  } else if (day >= 2) {
    return 8
  } else {
    return 8
  }
}

function timeRisk(time: number): number {

  if (time > 30) {
    return 8
  } else if (time > 25 && time <= 30) {
    return 8
  } else if (time > 20 && time <= 25) {
    return 8
  } else if (time > 15 && time <= 20) {
    return 7
  } else if (time > 10 && time <= 15) {
    return 7
  } else if (time > 5 && time <= 10) {
    return 4
  } else if (time > 0 && time <= 5) {
    return 1
  } else {
    return 0
  }
}

function rssiRisk(inputRssi: number): number {
  var rssi = inputRssi
  if (inputRssi < 0) {
    rssi = inputRssi * -1
  }
  if (rssi > 73) {
    return 0
  } else if (rssi > 63 && rssi <= 73) {
    return 0
  } else if (rssi > 51 && rssi <= 63) {
    return 1
  } else if (rssi > 33 && rssi <= 51) {
    return 8
  } else if (rssi > 23 && rssi <= 33) {
    return 8
  } else if (rssi > 15 && rssi <= 23) {
    return 8
  } else if (rssi > 10 && rssi <= 15) {
    return 8
  } else {
    return 8
  }
}



export default getRisk;