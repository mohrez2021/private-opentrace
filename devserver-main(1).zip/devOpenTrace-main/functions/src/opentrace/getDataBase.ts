import config from "../config";
import * as admin from "firebase-admin";

import * as functions from "firebase-functions";
import { validateToken } from "./getUploadToken";

const getDataBase = async (uid: string, context: functions.https.CallableContext) => {
  console.log('getDataBase:', 'uid', uid);

    const records = await getDBCollection(uid);
    let recordCount=0
   
    records.forEach(element => {
      recordCount =+ element.records.length
    });
    return {
      status: "SUCCESS",
      totalSubmit: records.length,
      totalrecords: recordCount,
    }
  };
  
 
  
  
  async function getDBCollection(inputUid: string): Promise<any[]> {
    const server = admin.firestore().collection(config.upload.recordsDBCollection).get();
    return server.then(async (querySnapshot) => {
      const recordsLogs: any[] = [];
      const records: any[] = [];
      querySnapshot.forEach((doc) => {
        recordsLogs.push(doc.data());
      });
      console.log('getDataBase:', 'recordsLogs', recordsLogs.length);
      for await (const i of recordsLogs) {
        let { uid } = await validateToken(i.token, false);
        console.log('getDataBase:', 'uid2', uid);

        if(uid === inputUid){
          records.push({ records: i.records});
        }
      }
      
        return records;
  
    });
  
  }

  


  

  
  export default getDataBase;