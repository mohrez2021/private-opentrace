import * as admin from "firebase-admin";
import config from "../../config";
import formatTimestamp from "./formatTimestamp";

/**
 * Store upload logs in a Firebase database
 * @param id
 * @param log
 */

export async function storeUploadRecords(id: string, log: object) {
  const writeResult = await admin.firestore().collection(config.upload.recordsDBCollection).doc(id).set(log);
  console.log('storeUploadRecords:', 'upload records is recorded successfully at', formatTimestamp(writeResult.writeTime.seconds));
}